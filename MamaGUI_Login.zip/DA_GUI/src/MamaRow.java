

import javax.swing.*;

public class MamaRow extends JTable {

}
